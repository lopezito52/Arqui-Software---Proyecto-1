package com.example.appproyecto.ui

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.appproyecto.R
import com.example.appproyecto.data.ProgressRepository
import com.example.appproyecto.data.firebase.FirebaseProgressRepository
import com.example.appproyecto.databinding.ActivityEntrenamientoDetalleBinding // ¡IMPORTANTE: Renombrar el binding!
import com.example.appproyecto.domain.ProgressManager
import com.example.appproyecto.util.AppNavigator

class EntrenamientoDetalleActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEntrenamientoDetalleBinding // <-- Cambiado
    private lateinit var navigator: AppNavigator

    // Inyección de dependencias
    private val progressRepo: ProgressRepository = FirebaseProgressRepository()
    private val progressManager = ProgressManager(progressRepo)

    // Propiedades del ejercicio (en lugar de quiz)
    private var ejercicioId: Int = -1
    private lateinit var nombreEjercicio: String
    private lateinit var descripcionEjercicio: String
    private var imagenResId: Int = 0 // Recurso de imagen para el ejercicio

    // Estado de la UI
    private var isFavorito = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Asegúrate de que el nombre del layout coincida con el XML
        binding = ActivityEntrenamientoDetalleBinding.inflate(layoutInflater) // <-- Cambiado
        setContentView(binding.root)

        navigator = AppNavigator(this)

        // Cargar datos y configurar la UI
        obtenerDatosDelIntent()
        cargarContenidoDelEjercicio()
        poblarVistas()
        setupClickListeners()
        setupBottomNavigation()

        if (ejercicioId != -1) {
            loadFavoriteStatus()
        }
    }

    private fun obtenerDatosDelIntent() {
        // Ahora recibimos datos del ejercicio
        ejercicioId = intent.getIntExtra("ejercicioId", -1)
        nombreEjercicio = intent.getStringExtra("ejercicioNombre") ?: "Ejercicio no encontrado"
    }

    private fun cargarContenidoDelEjercicio() {
        // ...
        descripcionEjercicio = "Descripción detallada de cómo realizar ${nombreEjercicio} correctamente, enfocándose en la postura y la respiración."

        // Usamos un ícono genérico de Android. Este NUNCA dará error.
        imagenResId = android.R.drawable.ic_menu_report_image
    }

    private fun poblarVistas() {
        binding.tvNombreEjercicio.text = nombreEjercicio
        binding.tvDescripcionEjercicio.text = descripcionEjercicio
        binding.ivEjercicioImagen.setImageResource(imagenResId)
    }

    private fun loadFavoriteStatus() {
        // Asumiendo que ProgressManager puede manejar favoritos para ejercicios
        progressManager.loadEjercicioFavoriteStatus(ejercicioId) { result ->
            result.onSuccess { isFavoriteResult ->
                isFavorito = isFavoriteResult
                updateFavoriteIcon()
            }
        }
    }

    private fun setupClickListeners() {
        // El botón ahora marca el ejercicio como completado directamente
        binding.btnCompletar.setOnClickListener {
            marcarEjercicioCompletado()
        }

        binding.btnFavorito.setOnClickListener {
            if (ejercicioId == -1) return@setOnClickListener

            progressManager.toggleEjercicioFavoriteStatus(ejercicioId, isFavorito) { result ->
                if (result.isSuccess) {
                    isFavorito = !isFavorito
                    updateFavoriteIcon()
                } else {
                    Toast.makeText(this, "Error al guardar favorito", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    // ✅ Nuevo: Lógica para marcar el ejercicio como completado
    private fun marcarEjercicioCompletado() {
        // Aquí deberías llamar a tu ProgressManager para guardar el progreso
        // progressManager.marcarEjercicioComoCompletado(ejercicioId) { result -> ... }

        Toast.makeText(this, "¡Buen trabajo! Ejercicio completado.", Toast.LENGTH_SHORT).show()

        // Devolvemos el resultado a la pantalla anterior para que sepa que se completó
        val intent = Intent()
        intent.putExtra("ejercicioIdCompletado", ejercicioId)
        setResult(Activity.RESULT_OK, intent)
        finish() // Cierra esta pantalla y vuelve a la anterior
    }

    private fun updateFavoriteIcon() {
        val icon = if (isFavorito) R.drawable.ic_heart_filled else R.drawable.ic_heart_outline
        binding.btnFavorito.setImageResource(icon)
    }

    private fun setupBottomNavigation() {
        binding.bottomNavigation.selectedItemId = R.id.nav_calendar
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> { navigator.toHome(); finish(); true }
                R.id.nav_calendar -> { navigator.toProgreso(); true }
                R.id.nav_notifications -> { navigator.toNotifications(); finish(); true }
                R.id.nav_settings -> { navigator.toSettings(); finish(); true }
                else -> false
            }
        }
    }
}