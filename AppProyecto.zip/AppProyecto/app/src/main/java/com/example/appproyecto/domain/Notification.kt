package com.example.appproyecto.domain

// Modelo de datos para una notificación
data class Notification(
    val id: String,
    val title: String,
    val message: String,
    var read: Boolean
)