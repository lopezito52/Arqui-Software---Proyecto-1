package com.example.appproyecto.util

import android.content.res.Resources

/**
 * Convierte un valor de Int que representa DPs (Density-independent Pixels)
 * a su equivalente en Pixels (PX).
 */
fun Int.dpToPx(): Int = (this * Resources.getSystem().displayMetrics.density).toInt()