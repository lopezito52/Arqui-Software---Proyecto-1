package com.example.appproyecto.data.firebase

import com.example.appproyecto.data.ProgressRepository
import com.example.appproyecto.domain.ProgressSummary
import com.example.appproyecto.domain.TotalProgress
import com.example.appproyecto.util.DispatchGroup
import com.google.android.gms.tasks.Tasks
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.*
import com.google.firebase.ktx.Firebase

class FirebaseProgressRepository : ProgressRepository {

    // Usamos UNA SOLA instancia de la base de datos: Realtime Database
    private val db = FirebaseDatabase.getInstance().reference
    private val userId = Firebase.auth.currentUser?.uid

    // --- MÉTODOS PARA EL PROGRESO SEMANAL ---

    override fun getWeeklyProgress(
        onSuccess: (Map<String, Int>) -> Unit,
        onError: (Exception) -> Unit
    ) {
        db.child("progreso").child("semanal").get()
            .addOnSuccessListener { snap ->
                val result = mutableMapOf<String, Int>()
                snap.children.forEach { child ->
                    result[child.key ?: ""] = child.getValue(Int::class.java) ?: 0
                }
                onSuccess(result)
            }
            .addOnFailureListener(onError)
    }

    override fun setWeeklyProgress(
        dayKey: String,
        value: Int,
        onComplete: () -> Unit,
        onError: (Exception) -> Unit
    ) {
        db.child("progreso").child("semanal").child(dayKey)
            .setValue(value)
            .addOnSuccessListener { onComplete() }
            .addOnFailureListener(onError)
    }

    override fun loadQuizFavoriteStatus(quizIndex: Int, callback: (Result<Boolean>) -> Unit) {
        if (userId == null) {
            callback(Result.failure(Exception("Usuario no autenticado")))
            return
        }

        // Apuntamos a la ruta donde se guardan los quizzes favoritos
        val favoriteRef = db.child("progreso_usuarios").child(userId).child("quizzesFavoritos").child(quizIndex.toString())

        favoriteRef.get()
            .addOnSuccessListener { snapshot ->
                // Obtenemos el valor. Si no existe o es nulo, significa que no es favorito.
                val esFavorito = snapshot.getValue(Boolean::class.java) ?: false
                callback(Result.success(esFavorito))
            }
            .addOnFailureListener { e ->
                callback(Result.failure(e))
            }
    }

    // --- MÉTODOS PARA EJERCICIOS ---

    override fun marcarEjercicioComoCompletado(ejercicioId: Int, callback: (Result<Unit>) -> Unit) {
        if (userId == null) {
            callback(Result.failure(Exception("Usuario no autenticado")))
            return
        }
        db.child("progreso_usuarios").child(userId).child("ejerciciosCompletados").child("ejercicio_$ejercicioId")
            .setValue(true)
            .addOnSuccessListener { callback(Result.success(Unit)) }
            .addOnFailureListener { e -> callback(Result.failure(e)) }
    }

    override fun loadEjercicioFavoriteStatus(ejercicioId: Int, callback: (Result<Boolean>) -> Unit) {
        if (userId == null) {
            callback(Result.failure(Exception("Usuario no autenticado")))
            return
        }
        db.child("progreso_usuarios").child(userId).child("ejerciciosFavoritos").child(ejercicioId.toString())
            .get()
            .addOnSuccessListener { snapshot ->
                val esFavorito = snapshot.getValue(Boolean::class.java) ?: false
                callback(Result.success(esFavorito))
            }
            .addOnFailureListener { e -> callback(Result.failure(e)) }
    }

    override fun toggleEjercicioFavoriteStatus(ejercicioId: Int, esFavoritoActual: Boolean, callback: (Result<Unit>) -> Unit) {
        if (userId == null) {
            callback(Result.failure(Exception("Usuario no autenticado")))
            return
        }
        val favoriteRef = db.child("progreso_usuarios").child(userId).child("ejerciciosFavoritos").child(ejercicioId.toString())
        val nuevaOperacion = if (esFavoritoActual) null else true
        favoriteRef.setValue(nuevaOperacion)
            .addOnSuccessListener { callback(Result.success(Unit)) }
            .addOnFailureListener { e -> callback(Result.failure(e)) }
    }


    // --- MÉTODOS PARA PROGRESO DIARIO Y MÓDULOS ---

    override fun getDailyCompletedCount(date: String, onSuccess: (Int) -> Unit, onError: (Exception) -> Unit) {
        db.child("progreso_diario").child(date).get()
            .addOnSuccessListener { snapshot ->
                var total = 0
                snapshot.children.forEach { modulo ->
                    modulo.children.forEach { actividad ->
                        when (val valor = actividad.value) {
                            is Boolean -> if (valor) total++
                            is Map<*, *> -> if (valor["hecho"] == true) total++
                        }
                    }
                }
                onSuccess(total)
            }
            .addOnFailureListener(onError)
    }

    override fun toggleQuizFavoriteStatus(quizIndex: Int, isFavorito: Boolean, callback: (Result<Unit>) -> Unit) {
        if (userId == null) {
            callback(Result.failure(Exception("Usuario no autenticado")))
            return
        }

        // Define la ruta en tu base de datos para los quizzes favoritos
        val favoriteRef = db.child("progreso_usuarios").child(userId).child("quizzesFavoritos").child(quizIndex.toString())

        // Si ya es favorito, lo borramos (setValue(null)). Si no, lo marcamos como favorito (setValue(true)).
        val nuevaOperacion = if (isFavorito) null else true

        favoriteRef.setValue(nuevaOperacion)
            .addOnSuccessListener { callback(Result.success(Unit)) }
            .addOnFailureListener { e -> callback(Result.failure(e)) }
    }

    override fun saveModuleAccess(date: String, module: String, onComplete: () -> Unit, onError: (Exception) -> Unit) {
        val ref = db.child("progreso_diario").child(date).child(module).push()
        val data = mapOf("accedido" to true, "timestamp" to System.currentTimeMillis())
        ref.setValue(data)
            .addOnSuccessListener { onComplete() }
            .addOnFailureListener(onError)
    }

    override fun getVideosAndPagesSummary(onResult: (Result<ProgressSummary>) -> Unit) {
        val videosRef = db.child("progreso").child("videos_paso").child("vistos")
        val paginasRef = db.child("progreso").child("paginas_paso").child("vistos")

        videosRef.get().addOnSuccessListener { snapshotVideos ->
            val videos = snapshotVideos.value
            val (vistosVideos, totalVideos) = when (videos) {
                is List<*> -> videos.count { it == true } to videos.size
                is Map<*, *> -> videos.values.count { it == true } to videos.size
                else -> 0 to 0
            }

            paginasRef.get().addOnSuccessListener { snapshotPaginas ->
                val paginas = snapshotPaginas.value
                val (vistosPaginas, totalPaginas) = when (paginas) {
                    is List<*> -> paginas.count { it == true } to paginas.size
                    is Map<*, *> -> paginas.values.count { it == true } to paginas.size
                    else -> 0 to 0
                }

                val totalVistos = vistosVideos + vistosPaginas
                val totalItems = totalVideos + totalPaginas
                val porcentaje = if (totalItems > 0) (totalVistos * 100) / totalItems else 0

                onResult(Result.success(ProgressSummary(percentage = porcentaje)))
            }.addOnFailureListener {
                onResult(Result.failure(it))
            }
        }.addOnFailureListener {
            onResult(Result.failure(it))
        }
    }

    // ... en FirebaseProgressRepository.kt
    override fun getPagesProgress(onResult: (Result<List<Boolean>>) -> Unit) {
        db.child("progreso/paginas_paso/vistos").get()
            .addOnSuccessListener { snapshot ->
                val vistos = mutableListOf<Boolean>()
                val datos = snapshot.value
                if (datos is List<*>) {
                    datos.forEach { item ->
                        vistos.add(item as? Boolean ?: false)
                    }
                }
                onResult(Result.success(vistos))
            }
            .addOnFailureListener {
                onResult(Result.failure(it))
            }
    }

    override fun getQuizzesSummary(onResult: (Result<ProgressSummary>) -> Unit) {
        db.child("progreso").child("quizzes_entrenate").child("completados").get()
            .addOnSuccessListener { snapshot ->
                val datos = snapshot.value
                val (completados, total) = when (datos) {
                    is List<*> -> datos.count { it == true } to datos.size
                    is Map<*, *> -> datos.values.count { it == true } to datos.size
                    else -> 0 to 0
                }
                val porcentaje = if (total > 0) (completados * 100) / total else 0
                onResult(Result.success(ProgressSummary(percentage = porcentaje)))
            }.addOnFailureListener {
                onResult(Result.failure(it))
            }
    }

    // --- NUEVAS IMPLEMENTACIONES PARA LISTA Y DETALLE DE VIDEO ---

    override fun getVideosProgress(onResult: (Result<List<Boolean>>) -> Unit) {
        db.child("progreso/videos_paso/vistos").get()
            .addOnSuccessListener { snapshot ->
                val vistos = mutableListOf<Boolean>()
                val datos = snapshot.value
                if (datos is List<*>) {
                    datos.forEach { item ->
                        vistos.add(item as? Boolean ?: false)
                    }
                }
                onResult(Result.success(vistos))
            }
            .addOnFailureListener {
                onResult(Result.failure(it))
            }
    }

    override fun setVideoViewedStatus(videoIndex: Int, isViewed: Boolean, onComplete: (Result<Unit>) -> Unit) {
        db.child("progreso/videos_paso/vistos").child(videoIndex.toString())
            .setValue(isViewed)
            .addOnSuccessListener { onComplete(Result.success(Unit)) }
            .addOnFailureListener { onComplete(Result.failure(it)) }
    }

    override fun setVideoFavoriteStatus(videoIndex: Int, isFavorite: Boolean, onComplete: (Result<Unit>) -> Unit) {
        db.child("favoritos/videos_paso").child(videoIndex.toString())
            .setValue(isFavorite)
            .addOnSuccessListener { onComplete(Result.success(Unit)) }
            .addOnFailureListener { onComplete(Result.failure(it)) }
    }

    override fun incrementWeeklyProgress(dayKey: String, onComplete: (Result<Unit>) -> Unit) {
        db.child("progreso/semanal").child(dayKey)
            .runTransaction(object : Transaction.Handler {
                override fun doTransaction(currentData: MutableData): Transaction.Result {
                    val currentProgress = currentData.getValue(Int::class.java) ?: 0
                    if (currentProgress < 3) {
                        currentData.value = currentProgress + 1
                    }
                    return Transaction.success(currentData)
                }

                override fun onComplete(
                    error: DatabaseError?,
                    committed: Boolean,
                    snapshot: DataSnapshot?
                ) {
                    if (error != null) {
                        onComplete(Result.failure(error.toException()))
                    } else {
                        onComplete(Result.success(Unit))
                    }
                }
            })
    }

    // ... en FirebaseProgressRepository.kt
    override fun setPageViewedStatus(pageIndex: Int, isViewed: Boolean, onComplete: (Result<Unit>) -> Unit) {
        db.child("progreso/paginas_paso/vistos").child(pageIndex.toString())
            .setValue(isViewed)
            .addOnSuccessListener { onComplete(Result.success(Unit)) }
            .addOnFailureListener { onComplete(Result.failure(it)) }
    }

    override fun setPageFavoriteStatus(pageIndex: Int, isFavorite: Boolean, onComplete: (Result<Unit>) -> Unit) {
        db.child("favoritos/paginas_paso").child(pageIndex.toString())
            .setValue(isFavorite)
            .addOnSuccessListener { onComplete(Result.success(Unit)) }
            .addOnFailureListener { onComplete(Result.failure(it)) }
    }

    override fun getPageStatus(pageIndex: Int, onResult: (isViewed: Boolean, isFavorite: Boolean) -> Unit) {
        var isViewed = false
        var isFavorite = false
        val group = DispatchGroup()

        group.enter()
        db.child("progreso/paginas_paso/vistos").child(pageIndex.toString()).get()
            .addOnCompleteListener { task ->
                isViewed = task.result?.getValue(Boolean::class.java) ?: false
                group.leave()
            }

        group.enter()
        db.child("favoritos/paginas_paso").child(pageIndex.toString()).get()
            .addOnCompleteListener { task ->
                isFavorite = task.result?.getValue(Boolean::class.java) ?: false
                group.leave()
            }

        group.notify {
            onResult(isViewed, isFavorite)
        }
    }

    // ... en FirebaseProgressRepository.kt
    override fun getQuizFavoriteStatus(quizIndex: Int, onResult: (Result<Boolean>) -> Unit) {
        db.child("favoritos/quizzes").child(quizIndex.toString()).get()
            .addOnSuccessListener { snapshot ->
                val isFavorite = snapshot.getValue(Boolean::class.java) ?: false
                onResult(Result.success(isFavorite))
            }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }

    override fun setQuizFavoriteStatus(quizIndex: Int, isFavorite: Boolean, onComplete: (Result<Unit>) -> Unit) {
        db.child("favoritos/quizzes").child(quizIndex.toString()).setValue(isFavorite)
            .addOnSuccessListener { onComplete(Result.success(Unit)) }
            .addOnFailureListener { onComplete(Result.failure(it)) }
    }

    // ... en FirebaseProgressRepository.kt

    override fun resetAllProgress(onComplete: (Result<Unit>) -> Unit) {
        val progresoRef = db.child("progreso")
        val progresoDiarioRef = db.child("progreso_diario")

        // Estas "constantes mágicas" (4, 4, 10) ahora están aisladas en la capa de datos.
        val reiniciarVideos = progresoRef.child("videos_paso/vistos").setValue(List(5) { false })
        val reiniciarPaginas = progresoRef.child("paginas_paso/vistos").setValue(List(5) { false })
        val reiniciarEntrenate = progresoRef.child("quizzes_entrenate/completados").setValue(List(10) { false })
        val reiniciarSemanal = progresoRef.child("semanal").setValue(
            mapOf("lunes" to 0, "martes" to 0, "miercoles" to 0, "jueves" to 0, "viernes" to 0, "sabado" to 0, "domingo" to 0)
        )
        val eliminarProgresoDiario = progresoDiarioRef.removeValue()

        Tasks.whenAllComplete(reiniciarVideos, reiniciarPaginas, reiniciarEntrenate, reiniciarSemanal, eliminarProgresoDiario)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    onComplete(Result.success(Unit))
                } else {
                    val error = task.exception ?: Exception("Error desconocido al reiniciar el progreso")
                    onComplete(Result.failure(error))
                }
            }
    }

    override fun getTotalProgress(onResult: (Result<TotalProgress>) -> Unit) {
        val videosRef = db.child("progreso/videos_paso/vistos")
        val paginasRef = db.child("progreso/paginas_paso/vistos")
        val quizzesRef = db.child("progreso/quizzes_entrenate/completados")

        val allTasks = Tasks.whenAllSuccess<DataSnapshot>(videosRef.get(), paginasRef.get(), quizzesRef.get())

        allTasks.addOnSuccessListener { snapshots ->
            val vistosVideos = snapshotToBooleanList(snapshots[0])
            val vistosPaginas = snapshotToBooleanList(snapshots[1])
            val completadosEntrenate = snapshotToBooleanList(snapshots[2])

            val totalCompletados = vistosVideos.count { it } + vistosPaginas.count { it } + completadosEntrenate.count { it }
            val totalItems = vistosVideos.size + vistosPaginas.size + completadosEntrenate.size

            onResult(Result.success(TotalProgress(totalCompletados, totalItems)))
        }.addOnFailureListener {
            onResult(Result.failure(it))
        }
    }

    // Movemos la función de ayuda aquí, haciéndola privada.
    private fun snapshotToBooleanList(snapshot: DataSnapshot): List<Boolean> {
        return when (val value = snapshot.value) {
            is List<*> -> value.map { it as? Boolean ?: false }
            is Map<*, *> -> value.values.map { it as? Boolean ?: false }
            else -> emptyList()
        }
    }

    // ... en FirebaseProgressRepository.kt
    override fun getQuizzesProgress(onResult: (Result<List<Boolean>>) -> Unit) {
        db.child("progreso/quizzes_entrenate/completados").get()
            .addOnSuccessListener { snapshot ->
                val completados = mutableListOf<Boolean>()
                val datos = snapshot.value
                if (datos is List<*>) {
                    datos.forEach { item ->
                        completados.add(item as? Boolean ?: false)
                    }
                }
                onResult(Result.success(completados))
            }
            .addOnFailureListener {
                onResult(Result.failure(it))
            }
    }

    override fun saveQuizzesProgress(progress: List<Boolean>, onComplete: (Result<Unit>) -> Unit) {
        db.child("progreso/quizzes_entrenate/completados").setValue(progress)
            .addOnSuccessListener { onComplete(Result.success(Unit)) }
            .addOnFailureListener { onComplete(Result.failure(it)) }
    }

    // ... en FirebaseProgressRepository.kt
    override fun getFavoriteVideoIndices(onResult: (Result<List<Int>>) -> Unit) {
        db.child("favoritos/videos_paso").get()
            .addOnSuccessListener { snapshot ->
                val indices = mutableListOf<Int>()
                snapshot.children.forEach { child ->
                    val index = child.key?.toIntOrNull()
                    val isFavorite = child.getValue(Boolean::class.java) ?: false
                    if (index != null && isFavorite) {
                        indices.add(index)
                    }
                }
                onResult(Result.success(indices))
            }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }

    override fun getFavoriteQuizIndices(onResult: (Result<List<Int>>) -> Unit) {
        db.child("favoritos/quizzes").get()
            .addOnSuccessListener { snapshot ->
                val indices = mutableListOf<Int>()
                snapshot.children.forEach { child ->
                    val index = child.key?.toIntOrNull()
                    val isFavorite = child.getValue(Boolean::class.java) ?: false
                    if (index != null && isFavorite) {
                        indices.add(index)
                    }
                }
                onResult(Result.success(indices))
            }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }

    private val weeklyProgressListeners = mutableMapOf<ValueEventListener, DatabaseReference>()

    override fun listenToWeeklyProgress(onUpdate: (Result<Map<String, Int>>) -> Unit): Any {
        val dbRef = db.child("progreso/semanal")
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val result = mutableMapOf<String, Int>()
                if (snapshot.exists()) {
                    snapshot.children.forEach { child ->
                        result[child.key ?: ""] = child.getValue(Int::class.java) ?: 0
                    }
                    onUpdate(Result.success(result))
                } else {
                    // Si no existe, podemos inicializarlo
                    initializeWeeklyProgress()
                }
            }
            override fun onCancelled(error: DatabaseError) {
                onUpdate(Result.failure(error.toException()))
            }
        }
        dbRef.addValueEventListener(listener)
        weeklyProgressListeners[listener] = dbRef
        return listener // Devolvemos el listener para usarlo como referencia
    }

    override fun stopListeningToWeeklyProgress(listener: Any) {
        if (listener is ValueEventListener) {
            val dbRef = weeklyProgressListeners[listener]
            dbRef?.removeEventListener(listener)
            weeklyProgressListeners.remove(listener)
        }
    }

    override fun addActivityToCurrentDay(dayKey: String, onComplete: (Result<Unit>) -> Unit) {
        val dayRef = db.child("progreso/semanal").child(dayKey)
        dayRef.get().addOnSuccessListener { snapshot ->
            val progresoActual = snapshot.getValue(Int::class.java) ?: 0
            // La lógica de negocio ahora está aquí
            val nuevoProgreso = (progresoActual + 33).coerceAtMost(99)
            dayRef.setValue(nuevoProgreso)
                .addOnSuccessListener { onComplete(Result.success(Unit)) }
                .addOnFailureListener { onComplete(Result.failure(it)) }
        }.addOnFailureListener { onComplete(Result.failure(it)) }
    }

    // Función de ayuda para inicializar
    private fun initializeWeeklyProgress() {
        val progressData = mapOf("lunes" to 0, "martes" to 0, "miercoles" to 0, "jueves" to 0, "viernes" to 0, "sabado" to 0, "domingo" to 0)
        db.child("progreso/semanal").setValue(progressData)
    }

    override fun getVideoStatus(videoIndex: Int, onResult: (isViewed: Boolean, isFavorite: Boolean) -> Unit) {
        var isViewed = false
        var isFavorite = false
        val group = DispatchGroup() // Para sincronizar las dos llamadas asíncronas

        group.enter()
        db.child("progreso/videos_paso/vistos").child(videoIndex.toString()).get()
            .addOnCompleteListener { task ->
                isViewed = task.result?.getValue(Boolean::class.java) ?: false
                group.leave()
            }

        group.enter()
        db.child("favoritos/videos_paso").child(videoIndex.toString()).get()
            .addOnCompleteListener { task ->
                isFavorite = task.result?.getValue(Boolean::class.java) ?: false
                group.leave()
            }

        group.notify {
            onResult(isViewed, isFavorite)
        }
    }

}