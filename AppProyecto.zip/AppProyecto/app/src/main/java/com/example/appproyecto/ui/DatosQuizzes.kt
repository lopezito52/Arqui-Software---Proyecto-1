package com.example.appproyecto.ui

object DatosQuizzes {
    val listaPreguntas = listOf(
        "¿Qué tan útil ha sido la app para organizar tu rutina de ejercicio?",
        "¿Has notado una mejora en tu bienestar físico desde que usas la app?",
        "¿Con qué frecuencia utilizas las guías de la app (videos y lecturas)?",
        "En una escala del 1 al 4, ¿qué tan fácil de usar es la aplicación?",
        "¿Recomendarías esta app a un amigo o familiar?"
    )
}