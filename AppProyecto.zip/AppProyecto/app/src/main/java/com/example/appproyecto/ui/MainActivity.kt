package com.example.appproyecto.ui

import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.appproyecto.R
import com.example.appproyecto.data.ProgressRepository
import com.example.appproyecto.data.firebase.FirebaseProgressRepository
import com.example.appproyecto.databinding.ActivityMainBinding
import com.example.appproyecto.domain.ProgressManager
import com.example.appproyecto.util.AppNavigator // 1. Importar el Navigator
import com.example.appproyecto.util.DateUtils
import java.util.Calendar

class MainActivity : AppCompatActivity(), CalendarDialogFragment.OnDateSelectedListener {

    private lateinit var binding: ActivityMainBinding
    private lateinit var navigator: AppNavigator // 2. Añadir Navigator

    // Inyección de dependencias simple. La Activity no conoce la implementación (Firebase).
    private val progressRepo: ProgressRepository = FirebaseProgressRepository()
    private val progressManager = ProgressManager(progressRepo)

    // El Mapeo de vistas es una responsabilidad de la UI, por lo que está bien aquí.
    private val dayViews = mapOf(
        R.id.checkIcon1 to "lunes",
        R.id.checkIcon2 to "martes",
        R.id.checkIcon3 to "miercoles",
        R.id.checkIcon4 to "jueves",
        R.id.checkIcon5 to "viernes",
        R.id.checkIcon6 to "sabado",
        R.id.checkIcon7 to "domingo",
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        navigator = AppNavigator(this) // 3. Inicializar Navigator

        setupClickListeners()
        setupWeekProgress()
        setupCalendarIcon()
        setupBottomNavigation()

        // Carga de datos inicial
        cargarChecksSemana()
        actualizarProgresoResumen()
        verificarDiaCompletado()
    }

    private fun setupClickListeners() {
        binding.cardInstagram.setOnClickListener {
            navigator.toInstagram()
            guardarProgresoModulo("videos_paso")
        }

        binding.cardFavoritos.setOnClickListener {
            navigator.toFavoritos()
        }

        binding.cardEntrenate.setOnClickListener {
            navigator.toEntrenate()
        }

        binding.btnGo.setOnClickListener {
            navigator.toProgreso()
        }

        binding.btnVerTodo.setOnClickListener {
            navigator.toProgreso()
        }
    }

    // === LÓGICA DE DATOS MEDIADA POR EL MANAGER (Correcto) ===

    private fun verificarDiaCompletado() {
        val fechaHoy = DateUtils.todayString()
        progressManager.verificarDiaCompletado(
            fecha = fechaHoy,
            onResult = { completado ->
                if (completado) {
                    val dayKey = DateUtils.currentDayKey()
                    progressManager.marcarDiaCompletado(
                        dayKey,
                        onComplete = { cargarChecksSemana() }
                    )
                    Toast.makeText(this, "¡Día completado!", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    private fun cargarChecksSemana() {
        progressManager.cargarProgresoSemanal(onSuccess = { semanal ->
            // El resto de la lógica de UI se queda aquí, que es su lugar.
            val currentDayIndex = DateUtils.currentDayIndexForUI()
            dayViews.entries.toList().forEachIndexed { index, (viewId, dayName) ->
                val progresoDia = semanal[dayName] ?: 0
                val imageView = findViewById<ImageView>(viewId)

                if (progresoDia >= 3) {
                    imageView.setImageResource(R.drawable.ic_check)
                } else {
                    imageView.setImageDrawable(null)
                }

                val bg = when {
                    index == currentDayIndex -> R.drawable.bg_day_highlighted
                    progresoDia >= 3 -> R.drawable.bg_day_checked
                    else -> R.drawable.bg_day_unchecked
                }
                imageView.setBackgroundResource(bg)
            }
        })
    }

    private fun guardarProgresoModulo(nombreModulo: String) {
        val fechaHoy = DateUtils.todayString()
        progressManager.registrarAccesoAModulo(fechaHoy, nombreModulo)
    }

    /**
     * ✅ SRP y DIP CUMPLIDOS: Esta función ya no accede a Firebase.
     * Su única responsabilidad es tomar los datos del ProgressManager y actualizar la UI.
     */
    private fun actualizarProgresoResumen() {
        progressManager.loadSummaries(
            onVideosAndPagesResult = { summary ->
                binding.progressBar.progress = summary.percentage
                binding.progressText.text = "${summary.percentage}%"
            },
            onQuizzesResult = { summary ->
                binding.progressBar2.progress = summary.percentage
                binding.progressText2.text = "${summary.percentage}%"
            }
        )
    }


    // === LÓGICA DE CONFIGURACIÓN DE UI ===

    private fun setupWeekProgress() {
        val layout = binding.llDays ?: return
        val currentDayIndex = DateUtils.currentDayIndexForUI()
        for (i in 0 until layout.childCount) {
            val dayView = layout.getChildAt(i) as? LinearLayout ?: continue
            val iconId = resources.getIdentifier("checkIcon${i + 1}", "id", packageName)
            val icon = dayView.findViewById<ImageView>(iconId)
            icon?.setBackgroundResource(
                if (i == currentDayIndex) R.drawable.bg_day_highlighted
                else R.drawable.bg_day_unchecked
            )
        }
    }

    // En MainActivity.kt

    private fun setupCalendarIcon() {
        binding.calendarIcon.setOnClickListener {
            // 1. Pide los datos al ProgressManager
            progressManager.cargarProgresoSemanal(onSuccess = { progresoSemanal ->

                // 2. Prepara la lista de días completados para el fragment
                val diasCompletados = ArrayList<String>()
                progresoSemanal.forEach { (dia, progreso) ->
                    if (progreso >= 3) {
                        // Capitalizamos el día para que se vea mejor
                        diasCompletados.add(dia.replaceFirstChar { it.uppercase() })
                    }
                }

                // 3. Crea la instancia del fragment usando newInstance y pasando los datos
                val calendarDialog = CalendarDialogFragment.newInstance(diasCompletados)
                calendarDialog.listener = this
                calendarDialog.show(supportFragmentManager, "CalendarDialog")
            })
        }
    }

    /**
     * ✅ OCP CUMPLIDO: La navegación se delega al Navigator.
     * Si se añade un nuevo destino, esta clase no se modifica.
     */
    private fun setupBottomNavigation() {
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> true
                R.id.nav_calendar -> { navigator.toProgreso(); true }
                R.id.nav_notifications -> { navigator.toNotifications(); true }
                R.id.nav_settings -> { navigator.toSettings(); true }
                else -> false
            }
        }
    }

    // === LISTENER DEL CALENDARIO ===

    override fun onDateSelected(year: Int, month: Int, dayOfMonth: Int) {
        val calendar = Calendar.getInstance()
        calendar.set(year, month, dayOfMonth)

        val currentWeek = Calendar.getInstance().get(Calendar.WEEK_OF_YEAR)
        val selectedWeek = calendar.get(Calendar.WEEK_OF_YEAR)

        if (selectedWeek != currentWeek) {
            Toast.makeText(this, "Solo puedes ver los datos de la semana actual", Toast.LENGTH_SHORT).show()
            return
        }
        cargarChecksSemana()
    }
}