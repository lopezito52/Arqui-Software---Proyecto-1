package com.example.appproyecto.ui

data class ContenidoQuiz(
    val explicacion: String,
    val opciones: List<String>,
    val correcta: Int // No lo usaremos para encuestas, pero lo mantenemos por la estructura
)

object PreguntasRespuestas {

    fun obtenerContenido(pregunta: String): ContenidoQuiz {
        return when (pregunta) {
            "¿Qué tan útil ha sido la app para organizar tu rutina de ejercicio?" -> ContenidoQuiz(
                "Tu opinión nos ayuda a entender si las herramientas de planificación y seguimiento están funcionando como esperas. Queremos que organizar tus ejercicios sea fácil y motivador.",
                listOf("Nada útil", "Poco útil", "Útil", "Muy útil"),
                -1 // No hay respuesta "correcta"
            )
            "¿Has notado una mejora en tu bienestar físico desde que usas la app?" -> ContenidoQuiz(
                "El objetivo principal de la app es generar un impacto positivo en tu salud y condición física. Saber si percibes una mejora nos indica si vamos por el camino correcto.",
                listOf("No he notado cambios", "Una leve mejora", "Una mejora notable", "Ha cambiado mi vida"),
                -1
            )
            "¿Con qué frecuencia utilizas las guías de la app (videos y lecturas)?" -> ContenidoQuiz(
                "Esta pregunta nos ayuda a valorar qué tan relevante es el contenido educativo que ofrecemos y si debemos crear más guías o enfocarnos en otras funcionalidades.",
                listOf("Casi nunca", "Algunas veces al mes", "Varias veces a la semana", "Todos los días"),
                -1
            )
            "En una escala del 1 al 4, ¿qué tan fácil de usar es la aplicación?" -> ContenidoQuiz(
                "La experiencia de usuario es clave. Queremos que la app sea intuitiva y que encuentres todo lo que necesitas sin complicaciones. Tu puntuación nos guía para simplificar y mejorar el diseño.",
                listOf("1 (Muy difícil)", "2 (Algo difícil)", "3 (Fácil)", "4 (Muy fácil)"),
                -1
            )
            "¿Recomendarías esta app a un amigo o familiar?" -> ContenidoQuiz(
                "La recomendación es el mayor indicador de satisfacción. Saber si compartirías la app nos dice si realmente estamos aportando valor a tu vida.",
                listOf("Definitivamente no", "Probablemente no", "Quizás", "Definitivamente sí"),
                -1
            )
            else -> ContenidoQuiz(
                "Pregunta no encontrada.",
                listOf("Opción 1", "Opción 2", "Opción 3", "Opción 4"),
                -1
            )
        }
    }
}