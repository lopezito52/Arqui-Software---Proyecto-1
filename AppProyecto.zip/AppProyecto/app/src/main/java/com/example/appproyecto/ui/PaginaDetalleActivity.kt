package com.example.appproyecto.ui

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.appproyecto.R
import com.example.appproyecto.data.ProgressRepository
import com.example.appproyecto.data.firebase.FirebaseProgressRepository
import com.example.appproyecto.databinding.ActivityPaginaDetalleBinding
import com.example.appproyecto.domain.ProgressManager
import com.example.appproyecto.util.AppNavigator

class PaginaDetalleActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPaginaDetalleBinding
    private lateinit var navigator: AppNavigator

    // Inyección de dependencias
    private val progressRepo: ProgressRepository = FirebaseProgressRepository()
    private val progressManager = ProgressManager(progressRepo)

    // Variables de estado de la UI
    private var paginaIndex: Int = -1
    private var isFavorito = false
    private var isPaginaVista = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPaginaDetalleBinding.inflate(layoutInflater)
        setContentView(binding.root)

        navigator = AppNavigator(this)

        // 1. Recoger datos del Intent
        val paginaUrl = intent.getStringExtra("paginaUrl")
        paginaIndex = intent.getIntExtra("paginaIndex", -1)
        val titulo = intent.getStringExtra("paginaTitulo") ?: "Página"
        binding.tituloLink.text = titulo

        // 2. Configurar la UI
        paginaUrl?.let { setupWebView(it) }
        setupClickListeners()
        setupBottomNavigation()

        // 3. Cargar el estado inicial usando el Manager
        if (paginaIndex != -1) {
            loadInitialStatus()
        }
    }

    private fun loadInitialStatus() {
        progressManager.loadPageStatus(paginaIndex) { viewed, favorite ->
            this.isPaginaVista = viewed
            this.isFavorito = favorite
            updateUI()
        }
    }

    private fun setupClickListeners() {
        binding.btnMarcarLeido.setOnClickListener {
            if (paginaIndex == -1) return@setOnClickListener

            progressManager.togglePageViewedStatus(paginaIndex, isPaginaVista) {
                // Al completarse, navegamos de vuelta
                navigator.toPaginasPasoPaso()
                finish()
            }
        }

        binding.btnFavorito.setOnClickListener {
            if (paginaIndex == -1) return@setOnClickListener

            progressManager.togglePageFavoriteStatus(paginaIndex, isFavorito) { result ->
                if (result.isSuccess) {
                    isFavorito = !isFavorito
                    updateFavoriteIcon()
                } else {
                    Toast.makeText(this, "Error al guardar favorito", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun updateUI() {
        updateButtonAppearance()
        updateFavoriteIcon()
    }

    private fun updateButtonAppearance() {
        binding.btnMarcarLeido.text = if (isPaginaVista) "✅ Quitar visto" else "Marcar como leído"
    }

    private fun updateFavoriteIcon() {
        val icon = if (isFavorito) R.drawable.ic_heart_filled else R.drawable.ic_heart_outline
        binding.btnFavorito.setImageResource(icon)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView(paginaUrl: String) {
        binding.webViewLink.apply {
            settings.javaScriptEnabled = true
            webViewClient = WebViewClient()
            loadUrl(paginaUrl)
        }
    }

    private fun setupBottomNavigation() {
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> { navigator.toHome(); finish(); true }
                R.id.nav_calendar -> { navigator.toProgreso(); true }
                R.id.nav_notifications -> { navigator.toNotifications(); true }
                R.id.nav_settings -> { navigator.toSettings(); true }
                else -> false
            }
        }
    }
}