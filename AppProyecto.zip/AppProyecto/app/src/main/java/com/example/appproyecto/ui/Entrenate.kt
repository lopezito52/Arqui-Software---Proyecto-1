package com.example.appproyecto.ui

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.appproyecto.R
import com.example.appproyecto.data.ProgressRepository
import com.example.appproyecto.data.firebase.FirebaseProgressRepository
import com.example.appproyecto.databinding.ActivityEntrenateBinding
import com.example.appproyecto.domain.ProgressManager
import com.example.appproyecto.util.AppNavigator
import android.view.View
import android.view.ViewGroup

class Entrenate : AppCompatActivity() {

    companion object {
        const val REQUEST_CODE_QUIZ_DETALLE = 1001
    }

    private lateinit var binding: ActivityEntrenateBinding
    private lateinit var navigator: AppNavigator

    // Inyección de dependencias
    private val progressRepo: ProgressRepository = FirebaseProgressRepository()
    private val progressManager = ProgressManager(progressRepo)

    // 1. Usar la fuente única de datos, no una lista duplicada
    private val quizzes = DatosQuizzes.listaPreguntas

    private lateinit var completados: MutableList<Boolean>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEntrenateBinding.inflate(layoutInflater)
        setContentView(binding.root)

        navigator = AppNavigator(this)
        completados = MutableList(quizzes.size) { false }

        binding.listaQuizzes.setOnItemClickListener { _, _, position, _ ->
            val intent = Intent(this, EntrenamientoDetalleActivity::class.java).apply {
                putExtra("quizIndex", position)
                putExtra("quizPregunta", quizzes[position])
            }
            startActivityForResult(intent, REQUEST_CODE_QUIZ_DETALLE)
        }

        setupBottomNavigation()
    }

    override fun onResume() {
        super.onResume()
        cargarProgreso()
    }

    // 2. Cargar datos a través del Manager
    private fun cargarProgreso() {
        progressManager.loadQuizzesProgress { result ->
            result.onSuccess { progressList ->
                // Asegurarse de que la lista local tenga el mismo tamaño que la de Firebase
                if (progressList.size == completados.size) {
                    this.completados = progressList.toMutableList()
                }
                actualizarUI()
            }.onFailure {
                Toast.makeText(this, "Error al cargar progreso", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // 3. Centralizar las actualizaciones de UI
    private fun actualizarUI() {
        actualizarLista()
        actualizarBarraProgreso()
    }

    private fun actualizarLista() {
        val adaptador = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, quizzes) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val view = super.getView(position, convertView, parent)
                val icono = if (completados.getOrNull(position) == true) "✅ " else "⬜ "
                (view as TextView).text = icono + quizzes[position]
                return view
            }
        }
        binding.listaQuizzes.adapter = adaptador
    }

    private fun actualizarBarraProgreso() {
        val completadosCount = completados.count { it }
        val porcentaje = if (quizzes.isNotEmpty()) (completadosCount * 100) / quizzes.size else 0
        binding.progressBar.progress = porcentaje
        binding.tvProgreso.text = "Tu progreso: $porcentaje%"
    }

    // 4. Guardar datos a través del Manager
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_QUIZ_DETALLE && resultCode == RESULT_OK) {
            val index = data?.getIntExtra("quizIndex", -1) ?: -1
            if (index != -1 && index in completados.indices) {
                completados[index] = true
                progressManager.saveQuizzesProgress(completados) { result ->
                    result.onSuccess {
                        actualizarUI()
                    }.onFailure {
                        Toast.makeText(this, "Error al guardar progreso", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    // 5. Usar el Navigator
    private fun setupBottomNavigation() {
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> { navigator.toHome(); finish(); true }
                R.id.nav_calendar -> { navigator.toProgreso(); true }
                R.id.nav_notifications -> { navigator.toNotifications(); true }
                R.id.nav_settings -> { navigator.toSettings(); true }
                else -> false
            }
        }
    }
}