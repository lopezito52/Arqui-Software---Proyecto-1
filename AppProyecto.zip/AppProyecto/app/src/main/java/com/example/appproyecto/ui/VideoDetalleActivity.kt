package com.example.appproyecto.ui

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.appproyecto.R
import com.example.appproyecto.data.ProgressRepository
import com.example.appproyecto.data.firebase.FirebaseProgressRepository
import com.example.appproyecto.databinding.ActivityVideoDetalleBinding
import com.example.appproyecto.domain.ProgressManager
import com.example.appproyecto.util.AppNavigator

class VideoDetalleActivity : AppCompatActivity() {

    private lateinit var binding: ActivityVideoDetalleBinding
    private lateinit var navigator: AppNavigator

    // Inyección de dependencias
    private val progressRepo: ProgressRepository = FirebaseProgressRepository()
    private val progressManager = ProgressManager(progressRepo)

    // Variables de estado de la UI
    private var videoIndex: Int = -1
    private var isFavorito = false
    private var isVideoViewed = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityVideoDetalleBinding.inflate(layoutInflater)
        setContentView(binding.root)

        navigator = AppNavigator(this)

        // 1. Recoger datos del Intent
        val videoUrl = intent.getStringExtra("videoUrl")
        videoIndex = intent.getIntExtra("videoIndex", -1)
        val titulo = intent.getStringExtra("videoTitulo") ?: "Video"
        binding.tituloVideo.text = titulo

        // 2. Configurar la UI
        videoUrl?.let { setupVideoWebView(it) }
        setupClickListeners()
        setupBottomNavigation()

        // 3. Cargar el estado inicial
        if (videoIndex != -1) {
            loadInitialStatus()
        }
    }

    private fun loadInitialStatus() {
        progressManager.loadVideoStatus(videoIndex) { viewed, favorite ->
            this.isVideoViewed = viewed
            this.isFavorito = favorite
            updateUI()
        }
    }

    private fun setupClickListeners() {
        binding.btnMarcarVisto.setOnClickListener {
            if (videoIndex == -1) return@setOnClickListener

            progressManager.toggleVideoViewedStatus(videoIndex, isVideoViewed) {
                // Al completarse, volvemos a la pantalla anterior
                navigator.toVideosPasoPaso()
                finish()
            }
        }

        binding.btnFavorito.setOnClickListener {
            if (videoIndex == -1) return@setOnClickListener

            progressManager.toggleFavoriteStatus(videoIndex, isFavorito) { result ->
                if (result.isSuccess) {
                    isFavorito = !isFavorito
                    updateFavoriteIcon()
                } else {
                    Toast.makeText(this, "Error al guardar favorito", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun updateUI() {
        updateButtonAppearance()
        updateFavoriteIcon()
    }

    private fun updateButtonAppearance() {
        binding.btnMarcarVisto.text = if (isVideoViewed) "✅ Quitar visto" else "Marcar como visto"
    }

    private fun updateFavoriteIcon() {
        val icon = if (isFavorito) R.drawable.ic_heart_filled else R.drawable.ic_heart_outline
        binding.btnFavorito.setImageResource(icon)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupVideoWebView(videoUrl: String) {
        val embedUrl = videoUrl.replace("youtu.be/", "www.youtube.com/embed/")
            .substringBefore("?si=") // Limpiar parámetros extra

        val html = """
            <html><body style="margin:0;padding:0;overflow:hidden;">
            <iframe width="100%" height="100%" src="$embedUrl" frameborder="0" allowfullscreen></iframe>
            </body></html>
        """.trimIndent()

        binding.webViewVideo.apply {
            settings.javaScriptEnabled = true
            webViewClient = WebViewClient()
            loadData(html, "text/html", "utf-8")
        }
    }

    private fun setupBottomNavigation() {
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> { navigator.toHome(); finish(); true }
                R.id.nav_calendar -> { navigator.toProgreso(); true }
                R.id.nav_notifications -> { navigator.toNotifications(); true }
                R.id.nav_settings -> { navigator.toSettings(); true }
                else -> false
            }
        }
    }
}