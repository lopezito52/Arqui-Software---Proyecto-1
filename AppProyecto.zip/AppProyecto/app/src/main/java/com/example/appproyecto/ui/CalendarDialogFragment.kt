package com.example.appproyecto.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.example.appproyecto.databinding.FragmentCalendarDialogBinding
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class CalendarDialogFragment : BottomSheetDialogFragment() {

    private var _binding: FragmentCalendarDialogBinding? = null
    private val binding get() = _binding!!

    // 1. Ya no necesita SharedPreferences
    // private lateinit var prefs: android.content.SharedPreferences

    interface OnDateSelectedListener {
        fun onDateSelected(year: Int, month: Int, dayOfMonth: Int)
    }

    var listener: OnDateSelectedListener? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentCalendarDialogBinding.inflate(inflater, container, false)

        // 2. Recupera los datos de los argumentos en lugar de SharedPreferences
        val completedDays = arguments?.getStringArrayList(ARG_COMPLETED_DAYS) ?: listOf()

        val progressText = StringBuilder("Días completados:\n")
        if (completedDays.isEmpty()) {
            progressText.append("Aún no has completado ningún día esta semana.")
        } else {
            completedDays.forEach { day ->
                progressText.append("✓ $day\n")
            }
        }
        binding.tvProgressSummary.text = progressText.toString()

        binding.calendarView.setOnDateChangeListener { _, year, month, day ->
            listener?.onDateSelected(year, month, day)
            dismiss()
        }

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    // 3. Companion object para crear la instancia del fragment de forma segura
    companion object {
        private const val ARG_COMPLETED_DAYS = "completed_days"

        fun newInstance(completedDays: ArrayList<String>): CalendarDialogFragment {
            val fragment = CalendarDialogFragment()
            val args = Bundle()
            args.putStringArrayList(ARG_COMPLETED_DAYS, completedDays)
            fragment.arguments = args
            return fragment
        }
    }
}