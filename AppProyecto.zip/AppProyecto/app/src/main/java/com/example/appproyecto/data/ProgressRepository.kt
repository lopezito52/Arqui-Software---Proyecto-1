package com.example.appproyecto.data

import com.example.appproyecto.domain.ProgressSummary
import com.example.appproyecto.domain.TotalProgress

/**
 * DIP: La UI depende de esta ABSTRACCIÓN, no de Firebase.
 * SRP: Solo define operaciones de progreso (nada de UI).
 */
interface ProgressRepository {
    fun getWeeklyProgress(
        onSuccess: (Map<String, Int>) -> Unit,
        onError: (Exception) -> Unit = {}
    )

    fun setWeeklyProgress(
        dayKey: String,
        value: Int,
        onComplete: () -> Unit = {},
        onError: (Exception) -> Unit = {}
    )

    fun getDailyCompletedCount(
        date: String,
        onSuccess: (Int) -> Unit,
        onError: (Exception) -> Unit = {}
    )

    fun saveModuleAccess(
        date: String,
        module: String,
        onComplete: () -> Unit = {},
        onError: (Exception) -> Unit = {}
    )

    /**
     * NUEVO: Obtiene el resumen de progreso para videos y páginas.
     * @param onResult Callback que se invoca con el resultado (éxito o fallo).
     */
    fun getVideosAndPagesSummary(onResult: (Result<ProgressSummary>) -> Unit)

    /**
     * NUEVO: Obtiene el resumen de progreso para los quizzes.
     * @param onResult Callback que se invoca con el resultado (éxito o fallo).
     */
    fun getQuizzesSummary(onResult: (Result<ProgressSummary>) -> Unit)

    fun getVideosProgress(onResult: (Result<List<Boolean>>) -> Unit)

    // ... en la interfaz ProgressRepository

    // Para marcar un video como visto
    fun setVideoViewedStatus(videoIndex: Int, isViewed: Boolean, onComplete: (Result<Unit>) -> Unit)

    // Para manejar los favoritos
    fun setVideoFavoriteStatus(videoIndex: Int, isFavorite: Boolean, onComplete: (Result<Unit>) -> Unit)

    // Para la transacción del progreso semanal
    fun incrementWeeklyProgress(dayKey: String, onComplete: (Result<Unit>) -> Unit)

    // Para obtener el estado inicial de un video (visto y favorito)
    fun getVideoStatus(videoIndex: Int, onResult: (isViewed: Boolean, isFavorite: Boolean) -> Unit)

    // ... en la interfaz ProgressRepository
    fun getPagesProgress(onResult: (Result<List<Boolean>>) -> Unit)

    // ... en la interfaz ProgressRepository
    fun getQuizzesProgress(onResult: (Result<List<Boolean>>) -> Unit)
    fun saveQuizzesProgress(progress: List<Boolean>, onComplete: (Result<Unit>) -> Unit)

    // ... en la interfaz ProgressRepository
    fun getFavoriteVideoIndices(onResult: (Result<List<Int>>) -> Unit)
    fun getFavoriteQuizIndices(onResult: (Result<List<Int>>) -> Unit)

    // ... en la interfaz ProgressRepository
    fun setPageViewedStatus(pageIndex: Int, isViewed: Boolean, onComplete: (Result<Unit>) -> Unit)
    fun setPageFavoriteStatus(pageIndex: Int, isFavorite: Boolean, onComplete: (Result<Unit>) -> Unit)
    fun getPageStatus(pageIndex: Int, onResult: (isViewed: Boolean, isFavorite: Boolean) -> Unit)

    // ... en la interfaz ProgressRepository

    // Para manejar el listener en tiempo real
    fun listenToWeeklyProgress(onUpdate: (Result<Map<String, Int>>) -> Unit): Any // Usamos Any para ser agnósticos a la implementación
    fun stopListeningToWeeklyProgress(listener: Any)

    // Para la lógica de "sumar actividad"
    fun addActivityToCurrentDay(dayKey: String, onComplete: (Result<Unit>) -> Unit)

    // ... en la interfaz ProgressRepository
    fun getQuizFavoriteStatus(quizIndex: Int, onResult: (Result<Boolean>) -> Unit)
    fun setQuizFavoriteStatus(quizIndex: Int, isFavorite: Boolean, onComplete: (Result<Unit>) -> Unit)

    // ... en la interfaz ProgressRepository
    fun resetAllProgress(onComplete: (Result<Unit>) -> Unit)
    fun getTotalProgress(onResult: (Result<TotalProgress>) -> Unit)

    fun toggleQuizFavoriteStatus(quizIndex: Int, isFavorito: Boolean, callback: (Result<Unit>) -> Unit)
    fun loadQuizFavoriteStatus(quizIndex: Int, callback: (Result<Boolean>) -> Unit)


    // --- NUEVOS MÉTODOS PARA EJERCICIOS ---

    /**
     * Marca un ejercicio como completado en la base de datos.
     */
    fun marcarEjercicioComoCompletado(ejercicioId: Int, callback: (Result<Unit>) -> Unit)

    /**
     * Carga el estado de favorito (si lo es o no) de un ejercicio.
     */
    fun loadEjercicioFavoriteStatus(ejercicioId: Int, callback: (Result<Boolean>) -> Unit)

    /**
     * Añade o elimina un ejercicio de la lista de favoritos.
     * @param esFavoritoActual Si el ejercicio YA ES favorito (para saber si hay que borrarlo o añadirlo).
     */
    fun toggleEjercicioFavoriteStatus(ejercicioId: Int, esFavoritoActual: Boolean, callback: (Result<Unit>) -> Unit)
}