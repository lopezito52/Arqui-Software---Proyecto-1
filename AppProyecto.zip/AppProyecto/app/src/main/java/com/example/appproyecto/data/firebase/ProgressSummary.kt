package com.example.appproyecto.domain

/**
 * Modelo de datos simple para representar el resultado de un resumen de progreso.
 * SRP: Su única responsabilidad es contener los datos del resumen.
 */
data class ProgressSummary(val percentage: Int)