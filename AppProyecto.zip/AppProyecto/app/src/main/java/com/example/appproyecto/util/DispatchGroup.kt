package com.example.appproyecto.util

/**
 * Clase de ayuda para esperar que varias tareas asíncronas terminen
 * antes de ejecutar un bloque de código final.
 */
class DispatchGroup {
    private var count = 0
    private var runnable: (() -> Unit)? = null

    init {
        count = 0
    }

    @Synchronized
    fun enter() {
        count++
    }

    @Synchronized
    fun leave() {
        count--
        notifyIfNeeded()
    }

    fun notify(r: () -> Unit) {
        runnable = r
        notifyIfNeeded()
    }

    @Synchronized
    private fun notifyIfNeeded() {
        if (count == 0 && runnable != null) {
            runnable?.invoke()
        }
    }
}