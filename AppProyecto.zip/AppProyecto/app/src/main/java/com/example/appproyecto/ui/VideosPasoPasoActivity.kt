package com.example.appproyecto.ui

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.appproyecto.R
import com.example.appproyecto.data.ProgressRepository
import com.example.appproyecto.data.firebase.FirebaseProgressRepository
import com.example.appproyecto.databinding.ActivityVideosPasoPasoBinding
import com.example.appproyecto.domain.ProgressManager
import com.example.appproyecto.util.AppNavigator
import android.view.View
import android.view.ViewGroup

class VideosPasoPasoActivity : AppCompatActivity() {

    private lateinit var binding: ActivityVideosPasoPasoBinding
    private lateinit var navigator: AppNavigator

    // Inyección de dependencias
    private val progressRepo: ProgressRepository = FirebaseProgressRepository()
    private val progressManager = ProgressManager(progressRepo)

    // 1. ELIMINAMOS el objeto 'VideoContent' que estaba aquí.
    //    Ahora usamos la fuente única de datos 'ContentData'.
    private val videoTitles = ContentData.videoTitles
    private val videoUrls = ContentData.videoUrls

    private var vistos: List<Boolean> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityVideosPasoPasoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        navigator = AppNavigator(this)

        // 2. Usamos el AppNavigator para ir al detalle del video.
        binding.listaVideos.setOnItemClickListener { _, _, position, _ ->
            val url = videoUrls.getOrElse(position) { "" }
            val title = videoTitles[position]
            navigator.toVideoDetail(title, url, position)
        }

        setupBottomNavigation()
    }

    override fun onResume() {
        super.onResume()
        cargarProgreso()
    }

    private fun cargarProgreso() {
        progressManager.loadVideosProgress { result ->
            result.onSuccess { progressList ->
                this.vistos = if (progressList.size >= videoTitles.size) {
                    progressList
                } else {
                    val paddedList = progressList.toMutableList()
                    repeat(videoTitles.size - progressList.size) { paddedList.add(false) }
                    paddedList
                }
                actualizarUI()
            }.onFailure {
                Toast.makeText(this, "Error al cargar el progreso", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun actualizarUI() {
        actualizarLista()
        actualizarBarraProgreso()
    }

    private fun actualizarLista() {
        // 3. El adaptador ahora usa la lista 'videoTitles' de la clase.
        val adaptador = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, videoTitles) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val view = super.getView(position, convertView, parent)
                val icono = if (vistos.getOrNull(position) == true) "✔️ " else "⬜ "
                (view as TextView).text = icono + videoTitles[position]
                return view
            }
        }
        binding.listaVideos.adapter = adaptador
    }

    private fun actualizarBarraProgreso() {
        val completados = vistos.count { it }
        val porcentaje = if (videoTitles.isNotEmpty()) {
            (completados * 100) / videoTitles.size
        } else {
            0
        }
        binding.progressBar.progress = porcentaje
        binding.tvProgreso.text = "Tu progreso: $porcentaje%"
    }

    private fun setupBottomNavigation() {
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> { navigator.toHome(); finish(); true }
                R.id.nav_calendar -> { navigator.toProgreso(); true }
                R.id.nav_notifications -> { navigator.toNotifications(); true }
                R.id.nav_settings -> { navigator.toSettings(); true }
                else -> false
            }
        }
    }
}