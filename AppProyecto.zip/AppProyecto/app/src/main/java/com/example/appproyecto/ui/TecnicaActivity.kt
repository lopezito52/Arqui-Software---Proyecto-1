package com.example.appproyecto.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.appproyecto.R
import com.example.appproyecto.data.ProgressRepository
import com.example.appproyecto.data.firebase.FirebaseProgressRepository
import com.example.appproyecto.databinding.ActivityTecnicaMainBinding
import com.example.appproyecto.domain.ProgressManager
import com.example.appproyecto.util.AppNavigator

class TecnicaActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTecnicaMainBinding

    // 1. Inyectar dependencias (Manager y Navigator)
    private lateinit var navigator: AppNavigator
    private val progressRepo: ProgressRepository = FirebaseProgressRepository()
    private val progressManager = ProgressManager(progressRepo)

    // 2. Eliminar la referencia directa a Firebase
    // private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTecnicaMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        navigator = AppNavigator(this)

        setupBottomNavigation()

        // 3. Usar el Navigator para la navegación
        binding.btnVerVideos.setOnClickListener {
            navigator.toVideosPasoPaso()
        }
        binding.btnVerLecturas.setOnClickListener {
            navigator.toPaginasPasoPaso()
        }
    }

    override fun onResume() {
        super.onResume()
        cargarProgreso()
    }

    /**
     * 4. Delegar la carga de datos al Manager, cumpliendo SRP y DIP.
     * La Activity solo se encarga de mostrar el resultado en la UI.
     */
    private fun cargarProgreso() {
        // Reutilizamos la misma función que creamos para la pantalla anterior.
        progressManager.loadVideosProgress { result ->
            result.onSuccess { vistos ->
                val total = vistos.size
                val completados = vistos.count { it }
                val porcentaje = if (total > 0) (completados * 100) / total else 0

                binding.progressBar.progress = porcentaje
                binding.tvProgreso.text = "Tu progreso: $porcentaje%"
            }.onFailure {
                binding.tvProgreso.text = "No se pudo cargar el progreso"
                Toast.makeText(this, "Error: ${it.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /**
     * 5. Usar el Navigator en el menú, cumpliendo OCP.
     */
    private fun setupBottomNavigation() {
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> { navigator.toHome(); finish(); true }
                R.id.nav_calendar -> { navigator.toProgreso(); true }
                R.id.nav_notifications -> { navigator.toNotifications(); true }
                R.id.nav_settings -> { navigator.toSettings(); true }
                else -> false
            }
        }
    }
}