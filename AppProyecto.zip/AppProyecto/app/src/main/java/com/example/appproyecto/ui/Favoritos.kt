package com.example.appproyecto.ui

import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.appproyecto.R
import com.example.appproyecto.data.ProgressRepository
import com.example.appproyecto.data.firebase.FirebaseProgressRepository
import com.example.appproyecto.databinding.ActivityFavoritosBinding
import com.example.appproyecto.domain.ProgressManager
import com.example.appproyecto.util.AppNavigator

class Favoritos : AppCompatActivity() {

    private lateinit var binding: ActivityFavoritosBinding
    private lateinit var navigator: AppNavigator

    // Inyección de dependencias
    private val progressRepo: ProgressRepository = FirebaseProgressRepository()
    private val progressManager = ProgressManager(progressRepo)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFavoritosBinding.inflate(layoutInflater)
        setContentView(binding.root)

        navigator = AppNavigator(this)

        setupBottomNavigation()
    }

    override fun onResume() {
        super.onResume()
        // Recargamos los favoritos cada vez que la pantalla se vuelve visible
        cargarFavoritos()
    }

    private fun cargarFavoritos() {
        cargarFavoritosVideos()
        cargarFavoritosQuizzes()
    }

    /**
     * ✅ SRP/DIP CUMPLIDOS: La función pide los índices al manager,
     * filtra el contenido y luego delega la creación de la UI.
     */
    private fun cargarFavoritosVideos() {
        progressManager.loadFavoriteVideoIndices { result ->
            result.onSuccess { favoriteIndices ->
                val container = binding.containerInstagram
                container.removeAllViews() // Limpiar vistas antiguas

                favoriteIndices.forEach { index ->
                    val titulo = ContentData.videoTitles.getOrNull(index)
                    val url = ContentData.videoUrls.getOrNull(index)
                    if (titulo != null && url != null) {
                        val item = crearItemVideo(titulo, url, index)
                        container.addView(item)
                    }
                }
            }.onFailure {
                Toast.makeText(this, "Error al cargar favoritos de video", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun cargarFavoritosQuizzes() {
        progressManager.loadFavoriteQuizIndices { result ->
            result.onSuccess { favoriteIndices ->
                val container = binding.containerQuizzes
                container.removeAllViews()

                favoriteIndices.forEach { index ->
                    val pregunta = DatosQuizzes.listaPreguntas.getOrNull(index)
                    if (pregunta != null) {
                        val item = crearItemQuiz(pregunta, index)
                        container.addView(item)
                    }
                }
            }.onFailure {
                Toast.makeText(this, "Error al cargar favoritos de quiz", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Estas funciones son responsabilidad de la UI, así que está bien que permanezcan aquí.
    private fun crearItemVideo(titulo: String, url: String, index: Int): LinearLayout {
        // ... (el código de crearItemVideo no cambia, pero su OnClickListener sí)
        val layout = LinearLayout(this).apply { /* ... */ }
        val tv = TextView(this).apply { text = "❤️ $titulo"; textSize = 18f }
        val btnVer = TextView(this).apply {
            text = "▶ Ver"
            setOnClickListener {
                // ✅ OCP CUMPLIDO: Usa el navigator
                navigator.toVideoDetail(titulo, url, index)
            }
        }
        layout.addView(tv)
        layout.addView(btnVer)
        return layout
    }

    private fun crearItemQuiz(pregunta: String, index: Int): LinearLayout {
        // ... (el código de crearItemQuiz no cambia, pero su OnClickListener sí)
        val layout = LinearLayout(this).apply { /* ... */ }
        val tv = TextView(this).apply { text = "❤️ $pregunta"; textSize = 18f }
        val btnIr = TextView(this).apply {
            text = "📝 Ir al quiz"
            setOnClickListener {
                // ✅ OCP CUMPLIDO: Usa el navigator
                navigator.toQuizDetail(pregunta, index)
            }
        }
        layout.addView(tv)
        layout.addView(btnIr)
        return layout
    }

    private fun setupBottomNavigation() {
        binding.bottomNavigation.selectedItemId = R.id.nav_calendar
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> { navigator.toHome(); finish(); true }
                R.id.nav_calendar -> true
                R.id.nav_notifications -> { navigator.toNotifications(); finish(); true }
                R.id.nav_settings -> { navigator.toSettings(); finish(); true }
                else -> false
            }
        }
    }
}