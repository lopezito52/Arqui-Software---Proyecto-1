package com.example.appproyecto.domain

import com.example.appproyecto.data.ProgressRepository
import com.example.appproyecto.util.DateUtils
import com.example.appproyecto.util.DispatchGroup

/**
 * SRP: Reúne reglas de negocio de progreso (nada de Android/UI).
 * Es el intermediario entre la UI y el repositorio de datos.
 * Reutilizable por cualquier Activity/Fragment.
 */
class ProgressManager(private val repo: ProgressRepository) {

    fun verificarDiaCompletado(
        fecha: String,
        umbral: Int = 3,
        onResult: (Boolean) -> Unit,
        onError: (Exception) -> Unit = {}
    ) {
        repo.getDailyCompletedCount(fecha,
            onSuccess = { total -> onResult(total >= umbral) },
            onError = onError
        )
    }

    // ... en ProgressManager.kt
    fun loadQuizFavoriteStatus(quizIndex: Int, onResult: (Result<Boolean>) -> Unit) {
        repo.getQuizFavoriteStatus(quizIndex, onResult)
    }

    fun toggleQuizFavoriteStatus(quizIndex: Int, currentStatus: Boolean, onComplete: (Result<Unit>) -> Unit) {
        repo.setQuizFavoriteStatus(quizIndex, !currentStatus, onComplete)
    }

    fun cargarProgresoSemanal(
        onSuccess: (Map<String, Int>) -> Unit,
        onError: (Exception) -> Unit = {}
    ) = repo.getWeeklyProgress(onSuccess, onError)

    fun loadVideosProgress(onResult: (Result<List<Boolean>>) -> Unit) {
        repo.getVideosProgress(onResult)
    }


    // ... en ProgressManager

    fun loadVideoStatus(videoIndex: Int, onResult: (isViewed: Boolean, isFavorite: Boolean) -> Unit) {
        repo.getVideoStatus(videoIndex, onResult)
    }

    fun toggleVideoViewedStatus(videoIndex: Int, currentStatus: Boolean, onComplete: () -> Unit) {
        val newStatus = !currentStatus
        repo.setVideoViewedStatus(videoIndex, newStatus) { result ->
            if (result.isSuccess) {
                // Regla de negocio: Solo incrementamos si se marca como VISTO.
                if (newStatus) {
                    val dayKey = DateUtils.currentDayKey() // Reutilizamos DateUtils
                    repo.incrementWeeklyProgress(dayKey) {
                        onComplete() // Llama al callback después de que ambas operaciones terminen
                    }
                } else {
                    onComplete()
                }
            }
        }
    }

    // ... en ProgressManager.kt
    fun loadPageStatus(pageIndex: Int, onResult: (isViewed: Boolean, isFavorite: Boolean) -> Unit) {
        repo.getPageStatus(pageIndex, onResult)
    }

    fun togglePageViewedStatus(pageIndex: Int, currentStatus: Boolean, onComplete: () -> Unit) {
        val newStatus = !currentStatus
        repo.setPageViewedStatus(pageIndex, newStatus) { result ->
            if (result.isSuccess && newStatus) {
                // Regla de negocio: si se marca como LEÍDO, incrementa el progreso.
                val dayKey = DateUtils.currentDayKey()
                repo.incrementWeeklyProgress(dayKey) {
                    onComplete()
                }
            } else {
                onComplete()
            }
        }
    }
    // ... en ProgressManager.kt

    fun listenToWeeklyProgress(onUpdate: (Result<Map<String, Int>>) -> Unit): Any {
        return repo.listenToWeeklyProgress(onUpdate)
    }

    fun stopListeningToWeeklyProgress(listener: Any) {
        repo.stopListeningToWeeklyProgress(listener)
    }

    // La nueva función que reemplaza a la lógica compleja de la Activity
    fun loadSummariesAndProcessDailyActivity(
        onSummariesLoaded: (videosAndPages: ProgressSummary, quizzes: ProgressSummary) -> Unit
    ) {
        var videosPagesDone = false
        var quizzesDone = false

        // Usamos el DispatchGroup que ya teníamos para coordinar
        val group = DispatchGroup()

        group.enter()
        repo.getVideosAndPagesSummary { result ->
            result.onSuccess { summary ->
                if (summary.percentage > 0) videosPagesDone = true
                onSummariesLoaded(summary, ProgressSummary(0)) // Carga parcial
            }
            group.leave()
        }

        group.enter()
        repo.getQuizzesSummary { result ->
            result.onSuccess { summary ->
                if (summary.percentage > 0) quizzesDone = true
                // Aquí podríamos llamar a onSummariesLoaded de nuevo para el segundo progress bar
            }
            group.leave()
        }

        // Cuando ambas cargas terminen, decidimos si actualizamos el progreso del día
        group.notify {
            if (videosPagesDone || quizzesDone) {
                repo.addActivityToCurrentDay(DateUtils.currentDayKey()) {
                    // Opcional: un callback para saber que la escritura terminó
                }
            }
        }
    }

    fun togglePageFavoriteStatus(pageIndex: Int, currentStatus: Boolean, onComplete: (Result<Unit>) -> Unit) {
        repo.setPageFavoriteStatus(pageIndex, !currentStatus, onComplete)
    }

    fun toggleFavoriteStatus(videoIndex: Int, currentStatus: Boolean, onComplete: (Result<Unit>) -> Unit) {
        repo.setVideoFavoriteStatus(videoIndex, !currentStatus, onComplete)
    }

    fun marcarDiaCompletado(
        dayKey: String,
        valorCompleto: Int = 3,
        onComplete: () -> Unit = {},
        onError: (Exception) -> Unit = {}
    ) = repo.setWeeklyProgress(dayKey, valorCompleto, onComplete, onError)

    fun registrarAccesoAModulo(
        fecha: String,
        modulo: String,
        onComplete: () -> Unit = {},
        onError: (Exception) -> Unit = {}
    ) = repo.saveModuleAccess(fecha, modulo, onComplete, onError)

    // ... en ProgressManager.kt
    fun loadFavoriteVideoIndices(onResult: (Result<List<Int>>) -> Unit) {
        repo.getFavoriteVideoIndices(onResult)
    }

    fun loadFavoriteQuizIndices(onResult: (Result<List<Int>>) -> Unit) {
        repo.getFavoriteQuizIndices(onResult)
    }

    // ... en ProgressManager.kt
    fun resetAllProgress(onComplete: (Result<Unit>) -> Unit) {
        repo.resetAllProgress(onComplete)
    }

    fun loadTotalProgress(onResult: (Result<TotalProgress>) -> Unit) {
        repo.getTotalProgress(onResult)
    }
    fun loadSummaries(
        onVideosAndPagesResult: (ProgressSummary) -> Unit,
        onQuizzesResult: (ProgressSummary) -> Unit
    ) {
        repo.getVideosAndPagesSummary { result ->
            result.onSuccess(onVideosAndPagesResult)
            // Aquí podrías manejar el result.onFailure si quisieras mostrar un error
        }
        repo.getQuizzesSummary { result ->
            result.onSuccess(onQuizzesResult)
            // Igualmente, aquí puedes manejar el fallo
        }
    }

    // ... en ProgressManager.kt
    fun loadPagesProgress(onResult: (Result<List<Boolean>>) -> Unit) {
        repo.getPagesProgress(onResult)
    }

    // ... en ProgressManager.kt
    fun loadQuizzesProgress(onResult: (Result<List<Boolean>>) -> Unit) {
        repo.getQuizzesProgress(onResult)
    }

    fun saveQuizzesProgress(progress: List<Boolean>, onComplete: (Result<Unit>) -> Unit) {
        repo.saveQuizzesProgress(progress, onComplete)
    }

    // --- AÑADIR LOS NUEVOS MÉTODOS ---

    fun marcarEjercicioComoCompletado(ejercicioId: Int, callback: (Result<Unit>) -> Unit) {
        repo.marcarEjercicioComoCompletado(ejercicioId, callback)
    }

    fun loadEjercicioFavoriteStatus(ejercicioId: Int, callback: (Result<Boolean>) -> Unit) {
        repo.loadEjercicioFavoriteStatus(ejercicioId, callback)
    }

    fun toggleEjercicioFavoriteStatus(ejercicioId: Int, esFavoritoActual: Boolean, callback: (Result<Unit>) -> Unit) {
        repo.toggleEjercicioFavoriteStatus(ejercicioId, esFavoritoActual, callback)
    }

}