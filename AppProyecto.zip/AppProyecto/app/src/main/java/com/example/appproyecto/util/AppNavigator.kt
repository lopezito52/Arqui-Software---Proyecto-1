package com.example.appproyecto.util

import android.content.Context
import android.content.Intent
import com.example.appproyecto.ui.Entrenate
import com.example.appproyecto.ui.Favoritos
import com.example.appproyecto.ui.TecnicaActivity
import com.example.appproyecto.ui.MainActivity // <-- Asegúrate de importar MainActivity
import com.example.appproyecto.ui.Notifications
import com.example.appproyecto.ui.Progreso
import com.example.appproyecto.ui.VideoDetalleActivity
import com.example.appproyecto.ui.EntrenamientoDetalleActivity
import com.example.appproyecto.ui.VideosPasoPasoActivity
import com.example.appproyecto.ui.PaginasPasoPasoActivity
import com.example.appproyecto.ui.Settings
import com.example.appproyecto.ui.Creditos

class AppNavigator(private val context: Context) {

    /**
     * NUEVO: Método para navegar a la pantalla principal.
     */
    fun toHome() {
        context.startActivity(Intent(context, MainActivity::class.java))
    }

    // ... dentro de la clase AppNavigator
    fun toVideosPasoPaso() {
        context.startActivity(Intent(context, VideosPasoPasoActivity::class.java))
    }

    fun toPaginasPasoPaso() {
        context.startActivity(Intent(context, PaginasPasoPasoActivity::class.java))
    }

    fun toInstagram() {
        context.startActivity(Intent(context, TecnicaActivity::class.java))
    }

    fun toFavoritos() {
        context.startActivity(Intent(context, Favoritos::class.java))
    }

    fun toEntrenate() {
        context.startActivity(Intent(context, Entrenate::class.java))
    }

    fun toProgreso() {
        context.startActivity(Intent(context, Progreso::class.java))
    }

    fun toNotifications() {
        context.startActivity(Intent(context, Notifications::class.java))
    }

    fun toSettings() {
        context.startActivity(Intent(context, Settings::class.java))
    }

    // ... en AppNavigator.kt
    fun toVideoDetail(titulo: String, url: String, index: Int) {
        val intent = Intent(context, VideoDetalleActivity::class.java).apply {
            putExtra("videoTitulo", titulo)
            putExtra("videoUrl", url)
            putExtra("videoIndex", index)
        }
        context.startActivity(intent)
    }

    fun toQuizDetail(pregunta: String, index: Int) {
        val intent = Intent(context, EntrenamientoDetalleActivity::class.java).apply {
            putExtra("quizPregunta", pregunta)
            putExtra("quizIndex", index)
        }
        context.startActivity(intent)
    }
    // ... en AppNavigator.kt
    fun toCreditos() {
        context.startActivity(Intent(context, Creditos::class.java))
    }
}