package com.example.appproyecto.ui

// Un objeto para centralizar los datos de contenido que no están en la base de datos.
object ContentData {

    val videoTitles = listOf(
        "Instagram desde cero: Aprende a usarlo como un pro en 2025",
        "Trucos de Instagram dominalo cómo un experto!",
        "Cómo ganar más seguidores en Instagram sin pagar un peso",
        "Errores comunes en redes sociales que están arruinando tu perfil",
        "Crea un perfil de Instagram irresistible en solo 5 pasos"
    )

    val videoUrls = listOf(
        "https://youtu.be/Qf1ykPXWqw0?si=mRGwQ5tIiZe17lIq",
        "https://youtu.be/Ad-08JQqofE?si=mZgwG2eerpJoOi0L",
        "https://youtu.be/dTJrzRR1ylk?si=h1F4OARtQdJ930Jh",
        "https://youtu.be/u7i4JO_vLs0?si=NKeXCUd7GzAdPOtf",
        "https://youtu.be/B2E17NbT168?si=AIrRc9Tue-UR24wT"
    )

    // Y ya tenemos DatosQuizzes.listaPreguntas para los quizzes
}