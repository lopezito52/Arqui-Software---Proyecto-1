package com.example.appproyecto.data

import com.example.appproyecto.domain.Notification

// Interfaz que define las operaciones de datos para las notificaciones
interface NotificationRepository {
    fun getNotifications(onResult: (Result<List<Notification>>) -> Unit)
    fun markAsRead(notificationId: String, onResult: (Result<Unit>) -> Unit)
}

// Implementación que simula los datos
class MockNotificationRepository : NotificationRepository {

    // Simulación de una "base de datos" en memoria
    private val notifications = mutableListOf(
        Notification("1", "❕ No se te olvide entrenar hoy!", "Entrenar sirve para tu crecimiento personal", false),
        Notification("2", "❕ No se te olvide entrenar hoy!", "¡Ya vas por la mitad de tu entrenamiento!", false)
    )

    override fun getNotifications(onResult: (Result<List<Notification>>) -> Unit) {
        onResult(Result.success(notifications)) // Devuelve la lista actual
    }

    override fun markAsRead(notificationId: String, onResult: (Result<Unit>) -> Unit) {
        val notification = notifications.find { it.id == notificationId }
        if (notification != null) {
            notification.read = true
            onResult(Result.success(Unit))
        } else {
            onResult(Result.failure(Exception("Notificación no encontrada")))
        }
    }
}