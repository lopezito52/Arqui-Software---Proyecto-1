package com.example.appproyecto.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.appproyecto.R
import com.example.appproyecto.data.ProgressRepository
import com.example.appproyecto.data.firebase.FirebaseProgressRepository
import com.example.appproyecto.databinding.ActivityConfiguracionBinding
import com.example.appproyecto.domain.ProgressManager
import com.example.appproyecto.util.AppNavigator

class Settings : AppCompatActivity() {

    private lateinit var binding: ActivityConfiguracionBinding
    private lateinit var navigator: AppNavigator

    // Inyección de dependencias
    private val progressRepo: ProgressRepository = FirebaseProgressRepository()
    private val progressManager = ProgressManager(progressRepo)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityConfiguracionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        navigator = AppNavigator(this)

        setupClickListeners()
        setupBottomNavigation()
    }

    override fun onResume() {
        super.onResume()
        actualizarProgresoTotal()
    }

    private fun setupClickListeners() {
        binding.btnReiniciarProgreso.setOnClickListener {
            reiniciarProgreso()
        }
        binding.btnCreditos.setOnClickListener {
            navigator.toCreditos()
        }
    }

    /**
     * ✅ SRP/DIP CUMPLIDOS: La lógica crítica de reinicio ahora se delega
     * con una sola llamada segura al ProgressManager.
     */
    private fun reiniciarProgreso() {
        progressManager.resetAllProgress { result ->
            result.onSuccess {
                Toast.makeText(this, "Progreso reiniciado", Toast.LENGTH_SHORT).show()
                actualizarProgresoTotal() // Recargar la UI
            }.onFailure {
                Toast.makeText(this, "Error al reiniciar progreso", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /**
     * ✅ SRP/DIP CUMPLIDOS: La carga y cálculo del progreso total
     * también se delega al Manager.
     */
    private fun actualizarProgresoTotal() {
        progressManager.loadTotalProgress { result ->
            result.onSuccess { totalProgress ->
                binding.progressBar.progress = totalProgress.percentage
                binding.tvProgreso.text = "Progreso total: ${totalProgress.percentage}%"
            }.onFailure {
                Toast.makeText(this, "Error al cargar progreso total", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /**
     * ✅ OCP CUMPLIDO: La navegación es manejada por el Navigator.
     */
    private fun setupBottomNavigation() {
        binding.bottomNavigation.selectedItemId = R.id.nav_settings
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> { navigator.toHome(); finish(); true }
                R.id.nav_calendar -> { navigator.toProgreso(); finish(); true }
                R.id.nav_notifications -> { navigator.toNotifications(); finish(); true }
                R.id.nav_settings -> true
                else -> false
            }
        }
    }
}