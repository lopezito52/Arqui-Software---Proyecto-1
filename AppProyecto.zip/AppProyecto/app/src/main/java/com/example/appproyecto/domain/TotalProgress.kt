package com.example.appproyecto.domain

data class TotalProgress(val itemsCompletados: Int, val totalItems: Int) {

    // ESTA ES LA PROPIEDAD QUE PROBABLEMENTE FALTA 👇
    val percentage: Int
        get() = if (totalItems > 0) (itemsCompletados * 100) / totalItems else 0
}