package com.example.appproyecto.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.appproyecto.R
import com.example.appproyecto.databinding.ActivityCreditosBinding
import com.example.appproyecto.util.AppNavigator // 1. Importar el Navigator

class Creditos : AppCompatActivity() {

    private lateinit var binding: ActivityCreditosBinding
    private lateinit var navigator: AppNavigator // 2. Añadir la variable

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCreditosBinding.inflate(layoutInflater)
        setContentView(binding.root)

        navigator = AppNavigator(this) // 3. Inicializar el Navigator

        setupBottomNavigation()
    }

    /**
     * ✅ OCP CUMPLIDO: La navegación ahora es gestionada por el AppNavigator.
     * Esta clase ya no necesita saber cómo se llega a otras pantallas.
     */
    private fun setupBottomNavigation() {
        binding.bottomNavigation.selectedItemId = R.id.nav_settings
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    navigator.toHome()
                    finish()
                    true
                }
                R.id.nav_calendar -> {
                    navigator.toProgreso()
                    finish()
                    true
                }
                R.id.nav_notifications -> {
                    navigator.toNotifications()
                    finish()
                    true
                }
                R.id.nav_settings -> true // Ya estamos aquí, no hacemos nada
                else -> false
            }
        }
    }
}