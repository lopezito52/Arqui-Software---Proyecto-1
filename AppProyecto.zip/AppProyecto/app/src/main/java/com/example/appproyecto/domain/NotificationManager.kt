package com.example.appproyecto.domain

import com.example.appproyecto.data.NotificationRepository

// Manager para la lógica de negocio de las notificaciones
class NotificationManager(private val repository: NotificationRepository) {

    fun loadNotifications(onResult: (Result<List<Notification>>) -> Unit) {
        repository.getNotifications(onResult)
    }

    fun markNotificationAsRead(notification: Notification, onResult: (Result<Unit>) -> Unit) {
        repository.markAsRead(notification.id, onResult)
    }

}