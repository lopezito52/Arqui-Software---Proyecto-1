package com.example.appproyecto.data

import android.R // <-- IMPORTANTE: Añade esta línea
import com.example.appproyecto.R as AppR // Renombramos tu R para evitar conflictos

object ContenidoEjercicios {
    fun obtenerContenido(ejercicioId: Int): EjercicioDetalle {
        return when (ejercicioId) {
            // Todos usan el mismo ícono genérico del sistema
            0 -> EjercicioDetalle("Descripción de flexiones...", R.drawable.ic_menu_gallery)
            1 -> EjercicioDetalle("Descripción de sentadillas...", R.drawable.ic_menu_gallery)
            else -> EjercicioDetalle("Descripción no encontrada", R.drawable.ic_menu_gallery)
        }
    }
}

data class EjercicioDetalle(val descripcion: String, val imagenResId: Int)