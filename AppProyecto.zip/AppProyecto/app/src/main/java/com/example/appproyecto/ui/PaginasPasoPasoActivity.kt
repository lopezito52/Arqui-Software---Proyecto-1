package com.example.appproyecto.ui

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.appproyecto.R
import com.example.appproyecto.data.ProgressRepository
import com.example.appproyecto.data.firebase.FirebaseProgressRepository
import com.example.appproyecto.databinding.ActivityPaginasPasoPasoBinding
import com.example.appproyecto.domain.ProgressManager
import com.example.appproyecto.util.AppNavigator
import android.view.View
import android.view.ViewGroup

class PaginasPasoPasoActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPaginasPasoPasoBinding
    private lateinit var navigator: AppNavigator

    // Inyección de dependencias
    private val progressRepo: ProgressRepository = FirebaseProgressRepository()
    private val progressManager = ProgressManager(progressRepo)

    // Separamos el contenido de la lógica
    private object PageContent {
        val titulos = listOf(
            "Guía básica para Instagram en 2025",
            "Estrategias avanzadas para crecer en Instagram",
            "Cómo usar Instagram Stories para atraer seguidores",
            "Errores frecuentes en Instagram y cómo evitarlos",
            "Cómo crear contenido atractivo para Instagram"
        )
        val urls = listOf(
            "https://www.bitrix24.es/articles/siete-estrategias-para-tus-redes-sociales.php?utm_source=chatgpt.com",
            "https://brand24.com/blog/es/crear-presencia-en-las-redes-sociales/?utm_source=chatgpt.com",
            "https://www.bluehost.es/blog/como-mejorar-la-presencia-en-las-redes-sociales-consejos-comprobados-para-hacer-crecer-su-marca-en-linea/?langSwitch=true&utm_source=chatgpt.com",
            "https://eolocomunicacion.com/estrategias-para-aumentar-tu-visibilidad-en-redes-sociales/?utm_source=chatgpt.com",
            "https://seranking.com/es/blog/gestion-de-redes-sociales/?utm_source=chatgpt.com"
        )
    }

    private var vistos: List<Boolean> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPaginasPasoPasoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        navigator = AppNavigator(this)

        binding.listaPaginas.setOnItemClickListener { _, _, position, _ ->
            val intent = Intent(this, PaginaDetalleActivity::class.java).apply {
                putExtra("paginaUrl", PageContent.urls.getOrElse(position) { "" })
                putExtra("paginaIndex", position)
                putExtra("paginaTitulo", PageContent.titulos[position])
            }
            startActivity(intent)
        }

        setupBottomNavigation()
    }

    override fun onResume() {
        super.onResume()
        cargarProgreso()
    }

    /**
     * ✅ SRP/DIP: La función ya no habla con Firebase. Delega la carga de datos
     * al manager y se enfoca en su única tarea: actualizar la UI con el resultado.
     */
    private fun cargarProgreso() {
        progressManager.loadPagesProgress { result ->
            result.onSuccess { progressList ->
                this.vistos = if (progressList.size >= PageContent.titulos.size) {
                    progressList
                } else {
                    val paddedList = progressList.toMutableList()
                    repeat(PageContent.titulos.size - progressList.size) { paddedList.add(false) }
                    paddedList
                }
                actualizarUI()
            }.onFailure {
                Toast.makeText(this, "Error al cargar el progreso", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun actualizarUI() {
        actualizarLista()
        actualizarBarraProgreso()
    }

    private fun actualizarLista() {
        val adaptador = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, PageContent.titulos) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val view = super.getView(position, convertView, parent)
                val icono = if (vistos.getOrNull(position) == true) "✔️ " else "⬜ "
                (view as TextView).text = icono + PageContent.titulos[position]
                return view
            }
        }
        binding.listaPaginas.adapter = adaptador
    }

    private fun actualizarBarraProgreso() {
        val completados = vistos.count { it }
        val porcentaje = if (PageContent.titulos.isNotEmpty()) {
            (completados * 100) / PageContent.titulos.size
        } else {
            0
        }
        binding.progressBar.progress = porcentaje
        binding.tvProgreso.text = "Tu progreso: $porcentaje%"
    }

    /**
     * ✅ OCP: La navegación se delega completamente al AppNavigator.
     */
    private fun setupBottomNavigation() {
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> { navigator.toHome(); finish(); true }
                R.id.nav_calendar -> { navigator.toProgreso(); true }
                R.id.nav_notifications -> { navigator.toNotifications(); true }
                R.id.nav_settings -> { navigator.toSettings(); true }
                else -> false
            }
        }
    }
}