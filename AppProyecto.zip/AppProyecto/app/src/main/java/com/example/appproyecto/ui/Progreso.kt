package com.example.appproyecto.ui

import android.os.Bundle
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.appproyecto.R
import com.example.appproyecto.data.ProgressRepository
import com.example.appproyecto.data.firebase.FirebaseProgressRepository
import com.example.appproyecto.databinding.ProgresoBinding
import com.example.appproyecto.domain.ProgressManager
import com.example.appproyecto.util.AppNavigator
import com.example.appproyecto.util.DateUtils
import com.example.appproyecto.util.dpToPx

class Progreso : AppCompatActivity() {

    private lateinit var binding: ProgresoBinding
    private lateinit var navigator: AppNavigator

    // Inyección de dependencias
    private val progressRepo: ProgressRepository = FirebaseProgressRepository()
    private val progressManager = ProgressManager(progressRepo)

    private var progressListener: Any? = null

    private val dayViews = listOf(
        R.id.checkIcon1 to "lunes",
        R.id.checkIcon2 to "martes",
        R.id.checkIcon3 to "miercoles",
        R.id.checkIcon4 to "jueves",
        R.id.checkIcon5 to "viernes",
        R.id.checkIcon6 to "sabado",
        R.id.checkIcon7 to "domingo"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ProgresoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        navigator = AppNavigator(this)

        setupBottomNavigation()
        actualizarProgresoResumen()

        binding.cardInstagram.setOnClickListener { navigator.toInstagram() }
        binding.cardEntrenate.setOnClickListener { navigator.toEntrenate() }
    }

    override fun onResume() {
        super.onResume()
        setupProgressListener()
    }

    override fun onPause() {
        super.onPause()
        removeProgressListener()
    }

    private fun setupProgressListener() {
        progressListener = progressManager.listenToWeeklyProgress { result ->
            result.onSuccess { weeklyProgress ->
                dayViews.forEach { (viewId, dayName) ->
                    val progress = weeklyProgress[dayName] ?: 0
                    updateDayView(viewId, progress, dayName)
                }
            }.onFailure {
                Toast.makeText(this, "Error al cargar progreso semanal", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun removeProgressListener() {
        progressListener?.let {
            progressManager.stopListeningToWeeklyProgress(it)
            progressListener = null
        }
    }

    // La lógica de la UI se queda aquí, lo cual es correcto.
    private fun updateDayView(viewId: Int, progress: Int, dayName: String) {
        val imageView = findViewById<ImageView>(viewId)
        val maxHeight = 150
        val maxProgress = 99
        val height = ((progress.coerceIn(0, maxProgress) / maxProgress.toDouble()) * maxHeight).toInt().coerceAtLeast(30)

        imageView.layoutParams.height = height.dpToPx()
        imageView.requestLayout()

        val isCurrentDay = dayName == DateUtils.currentDayKey()
        imageView.setBackgroundResource(
            when {
                progress >= 99 -> R.drawable.bg_day_highlighted2
                progress >= 66 -> R.drawable.bg_day_completed_full
                progress >= 33 -> R.drawable.bg_day_completed_full
                isCurrentDay -> R.drawable.bg_day_completed_full
                else -> R.drawable.bg_day_unchecked2
            }
        )
    }

    private fun actualizarProgresoResumen() {
        // La lógica de los resúmenes de videos/páginas ya estaba en el manager
        progressManager.loadSummaries(
            onVideosAndPagesResult = { summary ->
                binding.progressBar.progress = summary.percentage
                binding.progressText.text = "${summary.percentage}%"
            },
            onQuizzesResult = { summary ->
                binding.progressBar2.progress = summary.percentage
                binding.progressText2.text = "${summary.percentage}%"
            }
        )

        // La nueva lógica que decide si se suma actividad al día
        // NOTA: Esto podría causar una pequeña sobre-escritura, idealmente se fusionaría en una sola llamada en el Manager
        progressManager.loadSummariesAndProcessDailyActivity { _, _ -> /* ya actualizado arriba */ }
    }

    private fun setupBottomNavigation() {
        binding.bottomNavigation.selectedItemId = R.id.nav_calendar
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> { navigator.toHome(); finish(); true }
                R.id.nav_calendar -> true
                R.id.nav_notifications -> { navigator.toNotifications(); finish(); true }
                R.id.nav_settings -> { navigator.toSettings(); finish(); true }
                else -> false
            }
        }
    }
}