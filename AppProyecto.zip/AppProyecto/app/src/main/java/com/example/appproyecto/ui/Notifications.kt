package com.example.appproyecto.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.appproyecto.R
import com.example.appproyecto.data.MockNotificationRepository
import com.example.appproyecto.data.NotificationRepository
import com.example.appproyecto.databinding.ActivityNotificationsBinding
import com.example.appproyecto.domain.Notification
import com.example.appproyecto.domain.NotificationManager
import com.example.appproyecto.util.AppNavigator

class Notifications : AppCompatActivity() {

    private lateinit var binding: ActivityNotificationsBinding
    private lateinit var navigator: AppNavigator

    // Inyección de dependencias para la lógica de notificaciones
    private val notificationRepo: NotificationRepository = MockNotificationRepository()
    private val notificationManager = NotificationManager(notificationRepo)

    private var notifications: List<Notification> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNotificationsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        navigator = AppNavigator(this)

        loadNotifications()

        binding.historyButton.setOnClickListener {
            Toast.makeText(this, "Mostrando notificaciones pasadas...", Toast.LENGTH_SHORT).show()
        }

        setupBottomNavigation()
    }

    private fun loadNotifications() {
        notificationManager.loadNotifications { result ->
            result.onSuccess { notificationList ->
                this.notifications = notificationList
                setupNotificationUI()
            }.onFailure {
                Toast.makeText(this, "Error al cargar notificaciones", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setupNotificationUI() {
        // Asumiendo que tienes un número fijo de vistas en tu layout

        // Primera notificación
        notifications.getOrNull(0)?.let { notif1 ->
            binding.notificationTitle1.text = notif1.title
            binding.notificationMessage1.text = notif1.message
            binding.readButton1.isEnabled = !notif1.read

            binding.readButton1.setOnClickListener {
                notificationManager.markNotificationAsRead(notif1) { result ->
                    if (result.isSuccess) {
                        Toast.makeText(this, "Notificación marcada como leída", Toast.LENGTH_SHORT).show()
                        binding.readButton1.isEnabled = false
                    }
                }
            }
        }

        // Segunda notificación
        notifications.getOrNull(1)?.let { notif2 ->
            binding.notificationTitle2.text = notif2.title
            binding.notificationMessage2.text = notif2.message
            binding.readButton2.isEnabled = !notif2.read

            binding.readButton2.setOnClickListener {
                notificationManager.markNotificationAsRead(notif2) { result ->
                    if (result.isSuccess) {
                        Toast.makeText(this, "Notificación marcada como leída", Toast.LENGTH_SHORT).show()
                        binding.readButton2.isEnabled = false
                    }
                }
            }
        }
    }

    private fun setupBottomNavigation() {
        // En esta pantalla, el ítem seleccionado debería ser 'nav_notifications'
        binding.bottomNavigation.selectedItemId = R.id.nav_notifications
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> { navigator.toHome(); finish(); true }
                R.id.nav_calendar -> { navigator.toProgreso(); finish(); true }
                R.id.nav_notifications -> true // Ya estamos aquí
                R.id.nav_settings -> { navigator.toSettings(); finish(); true }
                else -> false
            }
        }
    }
}